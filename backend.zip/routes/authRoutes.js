const express = require('express');
const { registerUser, loginUser } = require('../controllers/authController');
const authMiddleware = require('../middlewares/authMiddleware'); // Ensure middleware exists
const User = require('../models/User');

const router = express.Router();

router.post('/signup', registerUser);
router.post('/login', loginUser);
router.get('/user', authMiddleware, async (req, res) => {
    try {
        console.log("Checking data...")
        const user = await User.findById(req.user).select('-password'); // Fetch user by ID from token
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.status(200).json({ user });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

module.exports = router;
