const express = require('express');
const { bookFlight, getUserFlights } = require('../controllers/flightController');
const { validateFlightBooking } = require('../middlewares/validationMiddleware');
const authMiddleware = require('../middlewares/authMiddleware');
const router = express.Router();

router.post('/book', authMiddleware, validateFlightBooking, bookFlight);
router.get('/my-flights', authMiddleware, getUserFlights);

module.exports = router;
