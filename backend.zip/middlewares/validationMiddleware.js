const validateFlightBooking = (req, res, next) => {
    const { departure, destination, departureDate, arrivalDate, passengers, carrier } = req.body;

    if (!departure || !destination || !departureDate || !passengers || !carrier) {
        return res.status(400).json({ message: 'All required fields must be provided.' });
    }
    if (new Date(departureDate) >= new Date(arrivalDate)) {
        return res.status(400).json({ message: 'Arrival date must be after the departure date.' });
    }
    if (passengers <= 0) {
        return res.status(400).json({ message: 'Passengers must be at least 1.' });
    }

    next();
};

module.exports = { validateFlightBooking };
