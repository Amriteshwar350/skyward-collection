const Flight = require('../models/Flight');

// Function to book a flight
const bookFlight = async (req, res) => {
    const { departure, destination, departureDate, arrivalDate, passengers, carrier } = req.body;

    // Input Validation
    if (!departure || !destination || !departureDate || !passengers || !carrier) {
        return res.status(400).json({ message: 'All required fields must be provided.' });
    }
    if (new Date(departureDate) >= new Date(arrivalDate)) {
        return res.status(400).json({ message: 'Arrival date must be after the departure date.' });
    }
    if (passengers <= 0) {
        return res.status(400).json({ message: 'Passengers must be at least 1.' });
    }

    try {
        const userId = req.user; // Extracted from authMiddleware

        const flight = await Flight.create({
            departure,
            destination,
            departureDate,
            arrivalDate,
            passengers,
            carrier,
            user: userId,
        });

        res.status(201).json({
            message: 'Flight booked successfully!',
            flight,
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error while booking flight.', error: error.message });
    }
};

// Function to get all flights booked by the logged-in user
const getUserFlights = async (req, res) => {
    try {
        const userId = req.user; // Extracted from authMiddleware
        const flights = await Flight.find({ user: userId });

        res.status(200).json({
            message: 'Flights retrieved successfully!',
            flights,
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error while retrieving flights.', error: error.message });
    }
};

module.exports = { bookFlight, getUserFlights };
