const mongoose = require('mongoose');

const flightSchema = mongoose.Schema(
    {
        departure: { type: String, required: true, trim: true },
        destination: { type: String, required: true, trim: true },
        departureDate: { type: Date, required: true },
        arrivalDate: { type: Date, required: true },
        passengers: { type: Number, required: true, min: 1 },
        carrier: { type: String, required: true },
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        status: { type: String, default: 'Booked', enum: ['Booked', 'Cancelled', 'Completed'] }, // Optional
        price: { type: Number, default: 0 }, // Optional pricing field
    },
    { timestamps: true }
);

module.exports = mongoose.model('Flight', flightSchema);
