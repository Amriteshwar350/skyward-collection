import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home/Home';
import About from './pages/About/About';
import Fleet from './pages/Fleet/Fleet';
import Login from './pages/Login/Login';
import Signup from './pages/Signup/Signup';
import NotFound from './pages/NotFound/NotFound';
import GulfstreamPage from './pages/GulfstreamPage/GulfstreamPage';
import BombardierPage from './pages/BombardierPage/BombardierPage';
import EmbraerPage from './pages/EmbraerPage/EmbraerPage';
import HelicoptersPage from './pages/HelicoptersPage/HelicoptersPage';
import AirbusPage from './pages/AirbusPage/AirbusPage';
import BoeingPage from './pages/BoeingPage/BoeingPage';
import Dashboard from './pages/Dashboard/Dashboard';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/fleet" element={<Fleet />} />
      <Route path="/fleet/gulfstream" element={<GulfstreamPage />} />
      <Route path="/fleet/bombardier" element={<BombardierPage />} />
      <Route path="/fleet/embraer" element={<EmbraerPage />} />
      <Route path="/fleet/helicopters" element={<HelicoptersPage />} />
      <Route path="/fleet/airbus" element={<AirbusPage />} />
      <Route path="/fleet/boeing" element={<BoeingPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;