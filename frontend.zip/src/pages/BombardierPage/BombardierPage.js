import React from 'react';
import './ManufacturerPage.css';

const BombardierPage = () => {
    const jets = [
        {
            name: 'Bombardier Global 7500',
            image: '/assets/images/global7500.jpg',
            description: 'The world’s largest and longest range business jet.',
            range: '7,700 nm',
            capacity: '14 passengers',
        },
        {
            name: 'Bombardier Global 6000',
            image: '/assets/images/global6000.jpg',
            description: 'Designed to deliver unmatched performance and luxurious comfort.',
            range: '6,000 nm',
            capacity: '13 passengers',
        },
        {
            name: 'Bombardier Challenger 650',
            image: '/assets/images/challenger650.jpg',
            description: 'Combining timeless aesthetics with advanced engineering.',
            range: '4,000 nm',
            capacity: '12 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Bombardier Jets</h1>
            <div className="jets-list">
                {jets.map((jet, index) => (
                    <div key={index} className="jet-card">
                        <img src={jet.image} alt={jet.name} className="jet-image" />
                        <h3 className="jet-name">{jet.name}</h3>
                        <p className="jet-description">{jet.description}</p>
                        <p className="jet-details">Range: {jet.range} | Capacity: {jet.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default BombardierPage;
