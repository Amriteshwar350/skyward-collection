import React from 'react';
import './ManufacturerPage.css';

const BoeingPage = () => {
    const jets = [
        {
            name: 'Boeing 737',
            image: '/assets/images/boeing737.jpg',
            description: 'The Boeing 737 offers a spacious cabin and is ideal for short to medium-haul flights.',
            range: '3,000 nm',
            capacity: '20 passengers',
        },
        {
            name: 'Boeing 767',
            image: '/assets/images/boeing767.jpg',
            description: 'The Boeing 767 provides a luxurious experience for long-haul journeys.',
            range: '4,000 nm',
            capacity: '22 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Boeing Jets</h1>
            <div className="jets-list">
                {jets.map((jet, index) => (
                    <div key={index} className="jet-card">
                        <img src={jet.image} alt={jet.name} className="jet-image" />
                        <h3 className="jet-name">{jet.name}</h3>
                        <p className="jet-description">{jet.description}</p>
                        <p className="jet-details">Range: {jet.range} | Capacity: {jet.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default BoeingPage;
