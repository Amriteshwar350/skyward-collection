import React from 'react';
import HeroSection from '../../components/HeroSection/HeroSection';
import Features from '../../components/Features/Features';
import Mission from '../../components/Mission/Mission';
import Testimonials from '../../components/Testimonials/Testimonials';
import Footer from '../../components/Footer/Footer';
import BookFlight from '../../components/BookFlight/BookFlight'; // Import the BookFlight component

const Home = () => {
    return (
        <>
            <HeroSection />
            <BookFlight /> {/* Add the BookFlight component here */}
            <div id="features-section">
                <Features />
            </div>
            <Mission />
            <Testimonials />
            <Footer />
        </>
    );
}

export default Home;
