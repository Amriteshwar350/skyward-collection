import React, { useState } from 'react';
import axios from 'axios';
import './Signup.css';

const Signup = () => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        phone: '',
        contactMethod: '',
        address: '',
        membership: '',
    });
    const [error, setError] = useState('');

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSignup = async (e) => {
        e.preventDefault();

        try {
            await axios.post('http://localhost:5000/api/auth/signup', {
                name: formData.name,
                email: formData.email,
                password: formData.password,
            });
            alert('Signup successful! Please login.');
        } catch (err) {
            setError(err.response?.data?.message || 'Error signing up');
        }
    };

    const nextStep = () => setStep(step + 1);
    const prevStep = () => setStep(step - 1);

    return (
        <div className="signup-container">
            <div className="signup-content">
                <h2 className="signup-title">Join the Pinnacle of Luxury</h2>
                <p className="signup-subtitle">Step into the world of elegance</p>

                <div className="progress-bar">
                    <div className={`progress-step ${step >= 1 ? 'active' : ''}`}></div>
                    <div className={`progress-step ${step >= 2 ? 'active' : ''}`}></div>
                    <div className={`progress-step ${step >= 3 ? 'active' : ''}`}></div>
                </div>

                <form className="signup-form" onSubmit={handleSignup}>
                    {step === 1 && (
                        <div className="form-section">
                            <div className="input-group">
                                <label>Full Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    placeholder="Enter your full name"
                                    value={formData.name}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="input-group">
                                <label>Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="Enter your email"
                                    value={formData.email}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="input-group">
                                <label>Password</label>
                                <input
                                    type="password"
                                    name="password"
                                    placeholder="Create a password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <button type="button" className="signup-button" onClick={nextStep}>
                                Next
                            </button>
                        </div>
                    )}
                    {step === 2 && (
                        <div className="form-section">
                            <div className="input-group">
                                <label>Phone Number</label>
                                <input
                                    type="tel"
                                    name="phone"
                                    placeholder="Enter your phone number"
                                    value={formData.phone}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="input-group">
                                <label>Preferred Contact Method</label>
                                <select
                                    name="contactMethod"
                                    value={formData.contactMethod}
                                    onChange={handleChange}
                                >
                                    <option value="Email">Email</option>
                                    <option value="Phone">Phone</option>
                                    <option value="SMS">SMS</option>
                                </select>
                            </div>
                            <div className="input-group">
                                <label>Address</label>
                                <input
                                    type="text"
                                    name="address"
                                    placeholder="Enter your address"
                                    value={formData.address}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <button type="button" className="signup-button" onClick={nextStep}>
                                Next
                            </button>
                            <button type="button" className="signup-button" onClick={prevStep}>
                                Back
                            </button>
                        </div>
                    )}
                    {step === 3 && (
                        <div className="form-section">
                            <div className="input-group">
                                <label>Membership Type</label>
                                <select
                                    name="membership"
                                    value={formData.membership}
                                    onChange={handleChange}
                                >
                                    <option value="Standard">Standard</option>
                                    <option value="Premium">Premium</option>
                                    <option value="Elite">Elite</option>
                                </select>
                            </div>
                            <div className="input-group">
                                <label>Agree to Terms</label>
                                <input
                                    type="checkbox"
                                    required
                                />{' '}
                                I agree to the terms and conditions
                            </div>
                            <button type="submit" className="signup-button">
                                Sign Up
                            </button>
                            <button type="button" className="signup-button" onClick={prevStep}>
                                Back
                            </button>
                        </div>
                    )}
                </form>
                {error && <p className="error-message">{error}</p>}
            </div>
        </div>
    );
};

export default Signup;
