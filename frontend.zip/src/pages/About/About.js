import React, { useState } from 'react';
import './About.css';

const About = () => {
  const [currentCard, setCurrentCard] = useState(0);

  const sections = [
    {
      title: "Our Mission",
      content: "Our mission is to transform every journey into an extraordinary experience by providing world-class service, cutting-edge luxury, and personalized attention to detail.",
      image: "/assets/images/mission.jpg",
      position: "left"
    },
    {
      title: "Founder’s Vision",
      content: "Founded by [Amriteshwar Singh], Skyward Collection was born out of a desire to offer more than just travel—a desire to craft journeys that leave a lasting impression. With visionary leadership and a passion for luxury, we have created a brand synonymous with excellence and exclusivity.",
      image: "/assets/images/founder.jpg",
      position: "right"
    },
    {
      title: "Our Values",
      content: "Integrity, Excellence, Innovation, and Uncompromising Quality are the pillars of Skyward Collection. We are committed to providing the highest level of service, ensuring that every aspect of your journey is tailored to perfection.",
      image: "/assets/images/values.jpg",
      position: "left"
    },
    {
      title: "Why Choose US?",
      content: "We believe in crafting personalized experiences that cater to the unique needs of each client, ensuring that every moment with Skyward Collection is unforgettable. Our global fleet, unparalleled service, and dedication to luxury set us apart from the competition.",
      image: "/assets/images/why-choose-us.jpg",
      position: "right"
    }
  ];

  const handleNavigation = (index) => {
    setCurrentCard(index);
  };

  return (
    <div className="about-page">
      {/* Hero Section */}
      <div className="about-hero">
        <h1 className="hero-title">Where Elegance Meets Excellence</h1>
        <p className="hero-subtitle">An unparalleled luxury experience, redefining private travel with elegance, and exclusivity.</p>
      </div>

      {/* Section Cards */}
      <div className="about-sections">
        {sections.map((section, index) => (
          <div
            key={index}
            className={`about-card ${section.position} ${currentCard === index ? 'active' : 'hidden'}`}
          >
            <div className="card-content">
              <h2 className="section-title">{section.title}</h2>
              <p className="section-content">{section.content}</p>
            </div>
            <div className="card-image">
              <img src={section.image} alt={section.title} />
            </div>
          </div>
        ))}
      </div>

      {/* Navigation */}
      <div className="about-navigation">
        <div className="nav-title">Explore Our Luxury Journeys</div>
        {sections.map((_, index) => (
          <button
            key={index}
            className={`nav-button ${currentCard === index ? 'active' : ''}`}
            onClick={() => handleNavigation(index)}
          >
            {sections[index].title}
          </button>
        ))}
      </div>

      {/* Call to Action */}
      <div className="about-section call-to-action">
        <h2 className="section-title">Join Us in Redefining Luxury Travel</h2>
        <p className="section-content">Explore our services or contact us to begin your journey. At Skyward Collection, we redefine luxury travel—making every journey as luxurious as the destination.</p>
      </div>
    </div>
  );
};

export default About;
