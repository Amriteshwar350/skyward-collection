import React from 'react';
import './ManufacturerPage.css';

const HelicoptersPage = () => {
    const helicopters = [
        {
            name: 'AgustaWestland AW109',
            image: '/assets/images/aw109.jpg',
            description: 'The AW109 offers exceptional speed and range for quick, luxurious trips.',
            range: '600 nm',
            capacity: '6 passengers',
        },
        {
            name: 'Bell 429',
            image: '/assets/images/bell429.jpg',
            description: 'The Bell 429 provides unparalleled flexibility and comfort for short-haul flights.',
            range: '400 nm',
            capacity: '7 passengers',
        },
        {
            name: 'Airbus H145',
            image: '/assets/images/h145.jpg',
            description: 'The H145 is a versatile helicopter offering both comfort and efficiency.',
            range: '400 nm',
            capacity: '8 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Helicopters</h1>
            <div className="jets-list">
                {helicopters.map((helicopter, index) => (
                    <div key={index} className="jet-card">
                        <img src={helicopter.image} alt={helicopter.name} className="jet-image" />
                        <h3 className="jet-name">{helicopter.name}</h3>
                        <p className="jet-description">{helicopter.description}</p>
                        <p className="jet-details">Range: {helicopter.range} | Capacity: {helicopter.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default HelicoptersPage;
