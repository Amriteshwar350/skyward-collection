import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Dashboard.css';

const Dashboard = () => {
    const [flights, setFlights] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchFlights = async () => {
            const token = localStorage.getItem('token'); // Ensure the user is logged in
            if (!token) {
                setError('You must be logged in to view your booked flights');
                return;
            }

            try {
                const response = await axios.get('http://localhost:5000/api/flights/my-flights', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setFlights(response.data.flights);
                setError('');
            } catch (err) {
                setError(err.response?.data?.message || 'Error fetching booked flights');
            }
        };

        fetchFlights();
    }, []);

    return (
        <div className="dashboard-container">
            <h1>Welcome to Your Dashboard</h1>
            {error && <p className="error-message">{error}</p>}
            {!error && flights.length === 0 && <p>No booked flights found.</p>}
            {flights.length > 0 && (
                <div className="flights-list">
                    {flights.map((flight) => (
                        <div key={flight._id} className="flight-card">
                            <h3>{flight.carrier}</h3>
                            <p><strong>Departure:</strong> {flight.departure}</p>
                            <p><strong>Destination:</strong> {flight.destination}</p>
                            <p><strong>Departure Date:</strong> {new Date(flight.departureDate).toLocaleDateString()}</p>
                            <p><strong>Arrival Date:</strong> {new Date(flight.arrivalDate).toLocaleDateString()}</p>
                            <p><strong>Passengers:</strong> {flight.passengers}</p>
                            <p><strong>Status:</strong> {flight.status}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Dashboard;
