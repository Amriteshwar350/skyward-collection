import React from 'react';

const NotFound = () => {
  return <div>404 - Page Not Found</div>;
};

export default NotFound;
