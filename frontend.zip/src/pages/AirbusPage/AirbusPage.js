import React from 'react';
import './ManufacturerPage.css';

const AirbusPage = () => {
    const jets = [
        {
            name: 'Airbus A350',
            image: '/assets/images/a350.jpg',
            description: 'The Airbus A350 offers unparalleled luxury and range, perfect for long-haul journeys.',
            range: '8,000 nm',
            capacity: '25 passengers',
        },
        {
            name: 'Airbus A320',
            image: '/assets/images/a320.jpg',
            description: 'The Airbus A320 is a versatile jet, ideal for both short and medium-haul flights.',
            range: '3,300 nm',
            capacity: '16 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Airbus Jets</h1>
            <div className="jets-list">
                {jets.map((jet, index) => (
                    <div key={index} className="jet-card">
                        <img src={jet.image} alt={jet.name} className="jet-image" />
                        <h3 className="jet-name">{jet.name}</h3>
                        <p className="jet-description">{jet.description}</p>
                        <p className="jet-details">Range: {jet.range} | Capacity: {jet.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default AirbusPage;
