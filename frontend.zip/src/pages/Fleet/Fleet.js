import React from 'react';
import { Link } from 'react-router-dom';
import './Fleet.css';

const Fleet = () => {
    return (
        <div className="fleet-container">
            <h1 className="fleet-title">Our Private Jet Fleet</h1>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/gulfstream-main.jpg" alt="Gulfstream" />
                    <h2>Gulfstream</h2>
                    <p>
                        Aircraft manufactured by Gulfstream are designed for long-range and high-speed travel,
                        providing luxury, comfort, and efficiency.
                    </p>
                    <Link to="/fleet/gulfstream" className="discover-button">Discover Gulfstream Jets</Link>
                </div>
            </div>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/bombardier-main.jpg" alt="Bombardier" />
                    <h2>Bombardier</h2>
                    <p>
                        Bombardier jets offer a blend of comfort and performance with advanced technology,
                        making them the perfect choice for luxury travel.
                    </p>
                    <Link to="/fleet/bombardier" className="discover-button">Discover Bombardier Jets</Link>
                </div>
            </div>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/embraer-main.jpg" alt="Embraer" />
                    <h2>Embraer</h2>
                    <p>
                        Embraer jets combine innovative design with high performance, offering a sophisticated
                        travel experience.
                    </p>
                    <Link to="/fleet/embraer" className="discover-button">Discover Embraer Jets</Link>
                </div>
            </div>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/helicopter-main.jpg" alt="Helicopters" />
                    <h2>Helicopters</h2>
                    <p>
                        Our helicopter fleet offers flexibility and speed for short-haul journeys, making them
                        ideal for business meetings and quick trips.
                    </p>
                    <Link to="/fleet/helicopters" className="discover-button">Discover Helicopters</Link>
                </div>
            </div>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/airbus-main.jpg" alt="Airbus" />
                    <h2>Airbus</h2>
                    <p>
                        Experience unparalleled luxury with Airbus, the choice for those seeking the ultimate
                        in private aviation.
                    </p>
                    <Link to="/fleet/airbus" className="discover-button">Discover Airbus Jets</Link>
                </div>
            </div>

            <div className="manufacturer-section">
                <div className="manufacturer">
                    <img src="/assets/images/boeing-main.jpg" alt="Boeing" />
                    <h2>Boeing</h2>
                    <p>
                        Boeing aircraft provide a spacious and luxurious travel environment, perfect for large groups
                        or long-range travel.
                    </p>
                    <Link to="/fleet/boeing" className="discover-button">Discover Boeing Jets</Link>
                </div>
            </div>
        </div>
    );
}

export default Fleet;
