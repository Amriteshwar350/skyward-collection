import React from 'react';
import './ManufacturerPage.css';

const EmbraerPage = () => {
    const jets = [
        {
            name: 'Embraer Phenom 300',
            image: '/assets/images/phenom300.jpg',
            description: 'The Phenom 300 offers a perfect blend of performance and comfort for short flights.',
            range: '2,000 nm',
            capacity: '8 passengers',
        },
        {
            name: 'Embraer Legacy 650',
            image: '/assets/images/legacy650.jpg',
            description: 'The Legacy 650 is designed for long-range travel with luxury and efficiency.',
            range: '3,900 nm',
            capacity: '13 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Embraer Jets</h1>
            <div className="jets-list">
                {jets.map((jet, index) => (
                    <div key={index} className="jet-card">
                        <img src={jet.image} alt={jet.name} className="jet-image" />
                        <h3 className="jet-name">{jet.name}</h3>
                        <p className="jet-description">{jet.description}</p>
                        <p className="jet-details">Range: {jet.range} | Capacity: {jet.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default EmbraerPage;
