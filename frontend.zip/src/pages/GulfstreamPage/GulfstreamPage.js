import React from 'react';
import './ManufacturerPage.css';

const GulfstreamPage = () => {
    const jets = [
        {
            name: 'Gulfstream G700',
            image: '/assets/images/g700.jpg',
            description: 'Experience the ultimate in luxury and performance with the Gulfstream G700.',
            range: '7,500 nm',
            capacity: '16 passengers',
        },
        {
            name: 'Gulfstream G800',
            image: '/assets/images/g800.jpg',
            description: 'The G800 offers unparalleled range and comfort for global travel.',
            range: '8,000 nm',
            capacity: '19 passengers',
        },
        {
            name: 'Gulfstream G650',
            image: '/assets/images/g650.jpg',
            description: 'A pinnacle of innovation, luxury, and performance in aviation.',
            range: '7,000 nm',
            capacity: '18 passengers',
        },
    ];

    return (
        <div className="manufacturer-page-container">
            <h1 className="manufacturer-title">Gulfstream Jets</h1>
            <div className="jets-list">
                {jets.map((jet, index) => (
                    <div key={index} className="jet-card">
                        <img src={jet.image} alt={jet.name} className="jet-image" />
                        <h3 className="jet-name">{jet.name}</h3>
                        <p className="jet-description">{jet.description}</p>
                        <p className="jet-details">Range: {jet.range} | Capacity: {jet.capacity}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default GulfstreamPage;
