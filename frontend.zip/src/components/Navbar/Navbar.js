import React, { useState, useEffect } from 'react';
import { Link as ScrollLink } from 'react-scroll';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Navbar.css';

const Navbar = () => {
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const [isProfileOpen, setProfileOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [user, setUser] = useState(null);
    const navigate = useNavigate();

    const toggleDropdown = () => setDropdownOpen(!isDropdownOpen);
    const toggleProfile = () => setProfileOpen(!isProfileOpen);

    const handleSearch = (e) => {
        e.preventDefault();
        window.location.href = `/search?q=${e.target.query.value}`;
    };

    const handleScroll = () => {
        setIsScrolled(window.scrollY > 50);
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        // Fetch user details if logged in
        const fetchUserDetails = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                try {
                    const response = await axios.get('http://localhost:5000/api/auth/user', {
                        headers: { Authorization: `Bearer ${token}` },
                    });
                    setUser(response.data.user);
                } catch (error) {
                    console.error('Error fetching user details:', error);
                    setUser(null); // Clear user if token is invalid
                }
            }
        };
        fetchUserDetails();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('token');
        setUser(null);
        navigate('/login');
    };

    const handleBookFlightClick = () => {
        if (window.location.pathname !== '/') {
            navigate('/', { replace: true });
        }
        setTimeout(() => {
            window.scrollTo({
                top: document.getElementById('book-my-flight').offsetTop,
                behavior: 'smooth',
            });
        }, 100);
    };

    return (
        <nav className={`navbar-container ${isScrolled ? 'navbar-scrolled' : ''}`}>
            <div className="navbar-brand">
                <a href="/">Skyward Collection</a>
            </div>
            <ul className="navbar-links">
                <li className="nav-item">
                    <a href="/">Home</a>
                </li>
                <li className="nav-item dropdown">
                    <a href="#" className="dropdown-toggle" onClick={toggleDropdown}>Services</a>
                    {isDropdownOpen && (
                        <ul className="dropdown-menu">
                            <li><a href="/fleet">Fleet</a></li>
                            <li><a href="/membership">Membership</a></li>
                            <li>
                                <ScrollLink
                                    to="book-my-flight"
                                    smooth={true}
                                    duration={1000}
                                    onClick={handleBookFlightClick}
                                >
                                    Book Your Flight
                                </ScrollLink>
                            </li>
                        </ul>
                    )}
                </li>
                <li className="nav-item">
                    <a href="/about">About Us</a>
                </li>
            </ul>
            <div className="navbar-actions">
                <form className="search-bar" onSubmit={handleSearch}>
                    <input 
                        type="text" 
                        placeholder="Explore luxury..." 
                        name="query" 
                    />
                </form>
                <div className="profile-menu" onMouseEnter={toggleProfile} onMouseLeave={toggleProfile}>
                    <div className="profile-icon">👤</div>
                    {isProfileOpen && (
                        <div className="profile-dropdown">
                            {user ? (
                                <>
                                    <p>Welcome, {user.name}!</p>
                                    <a href="/dashboard">Dashboard</a>
                                    <a href="/settings">Account Settings</a>
                                    <a onClick={handleLogout} style={{ cursor: 'pointer' }}>Logout</a>
                                </>
                            ) : (
                                <>
                                    <a href="/login">Login</a>
                                    <a href="/signup">Signup</a>
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
