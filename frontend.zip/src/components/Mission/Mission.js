import React from 'react';
import './Mission.css';

const Mission = () => {
    return (
<section class="mission-container">
    <div class="mission-text">
        <h2 class="mission-header">Mastering Elegance</h2>
        <p>At Skyward Collection, our mission is to redefine luxury in aviation. We are committed to providing an experience that combines elegance, comfort, and exclusivity, ensuring every journey is as exceptional as our clients.</p>
    </div>
    <img src="/assets/images/mission-image.jpg" alt="Luxurious Aircraft Interior" class="mission-image" />
</section>
    );
}

export default Mission;
