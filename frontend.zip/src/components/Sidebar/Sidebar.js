import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom'; // Ensure useNavigate is imported
import './Sidebar.css';

const Sidebar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [username, setUsername] = useState('Guest');
    const [language, setLanguage] = useState('en');
    const [theme, setTheme] = useState('light');
    const [selectedFleet, setSelectedFleet] = useState(null);
    const [selectedMembership, setSelectedMembership] = useState(null);
    const [notifications, setNotifications] = useState([]);
    const [aiAssistantActive, setAiAssistantActive] = useState(false);
    const [flightStatus, setFlightStatus] = useState(null);
    const [recentActivity, setRecentActivity] = useState([]);
    const [userPreferences, setUserPreferences] = useState({});
    const navigate = useNavigate(); // Replace useHistory with useNavigate
    const location = useLocation();

    const toggleSidebar = () => {
        setIsOpen(!isOpen);
    };

    useEffect(() => {
        setIsOpen(false);
    }, [location]);

    useEffect(() => {
        const fetchUserData = async () => {
            await new Promise((resolve) => setTimeout(resolve, 500));

            const user = {
                loggedIn: true,
                name: 'Amriteshwar Singh',
                notifications: 3,
                flightStatus: 'On Time',
                recentActivity: ['Checked Fleet', 'Updated Preferences'],
                preferences: {
                    preferredLanguage: 'en',
                    preferredTheme: 'dark',
                }
            };

            if (user.loggedIn) {
                setIsLoggedIn(true);
                setUsername(user.name);
                setNotifications(new Array(user.notifications).fill('New Notification'));
                setFlightStatus(user.flightStatus);
                setRecentActivity(user.recentActivity);
                setUserPreferences(user.preferences);
                setLanguage(user.preferences.preferredLanguage);
                setTheme(user.preferences.preferredTheme);
            } else {
                setIsLoggedIn(false);
                setUsername('Guest');
                setNotifications([]);
                setRecentActivity([]);
                setUserPreferences({});
            }
        };

        fetchUserData();
    }, []);

    const handleLanguageChange = (e) => {
        const newLanguage = e.target.value;
        setLanguage(newLanguage);
        document.documentElement.lang = newLanguage;
        setUserPreferences((prev) => ({ ...prev, preferredLanguage: newLanguage }));
        console.log(`Language changed to: ${e.target.value}`);
    };

    const toggleTheme = () => {
        const newTheme = theme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
        document.body.className = `theme-${newTheme}`;
        setUserPreferences((prev) => ({ ...prev, preferredTheme: newTheme }));
        console.log(`Theme switched to: ${newTheme}`);
    };

    const handleFleetSelection = (manufacturer) => {
        setSelectedFleet(manufacturer);
        console.log(`Fleet selected: ${manufacturer}`);
        setRecentActivity((prev) => [...prev, `Viewed ${manufacturer} Fleet`]);
        navigate(`/fleet/${manufacturer.toLowerCase()}`);
    };

    const handleMembershipSelection = (plan) => {
        setSelectedMembership(plan);
        console.log(`Membership selected: ${plan}`);
        setRecentActivity((prev) => [...prev, `Viewed ${plan} Membership`]);
        navigate(`/membership/${plan.toLowerCase()}`);
    };

    const handleAIInteraction = () => {
        setAiAssistantActive(!aiAssistantActive);
        setRecentActivity((prev) => [...prev, aiAssistantActive ? 'Deactivated AI Assistant' : 'Activated AI Assistant']);
    };

    const handleNotifications = () => {
        console.log('Notifications panel opened.');
        setRecentActivity((prev) => [...prev, 'Viewed Notifications']);
    };

    const handleVoiceControl = () => {
        console.log('Voice control activated.');
        setRecentActivity((prev) => [...prev, 'Activated Voice Control']);
    };

    const handleInflightEntertainment = () => {
        console.log('Inflight Entertainment accessed.');
        navigate('/inflight/entertainment');
        setRecentActivity((prev) => [...prev, 'Accessed Inflight Entertainment']);
    };

    const handleMealSelection = () => {
        console.log('Meal Selection accessed.');
        navigate('/inflight/meals');
        setRecentActivity((prev) => [...prev, 'Accessed Meal Selection']);
    };

    const handleSeatAdjustment = () => {
        console.log('Seat Adjustment accessed.');
        navigate('/inflight/seat-adjustment');
        setRecentActivity((prev) => [...prev, 'Accessed Seat Adjustment']);
    };

    return (
        <>
            <div className="hamburger-icon" onClick={toggleSidebar}>
                <div className="bar"></div>
                <div className="bar"></div>
                <div className="bar"></div>
            </div>
            <div className={`sidebar-container ${isOpen ? 'active' : ''}`}>
                <div className="sidebar-header">
                    <h2 className="sidebar-welcome">
                        {isLoggedIn ? `Welcome, ${username}` : 'Welcome, Guest'}
                    </h2>
                    {!isLoggedIn && (
                        <div className="auth-options">
                            <Link to="/login" className="sidebar-auth-link">Login</Link>
                            <span className="divider">|</span>
                            <Link to="/signup" className="sidebar-auth-link">Sign Up</Link>
                            <span className="divider">|</span>
                            <Link to="/continue-as-guest" className="sidebar-auth-link">Continue as Guest</Link>
                        </div>
                    )}
                    {flightStatus && (
                        <div className="flight-status">
                            <p>Flight Status: <strong>{flightStatus}</strong></p>
                        </div>
                    )}
                </div>
                <ul className="sidebar-menu">
                    <li className="sidebar-item">
                        <Link to="/" className="sidebar-links">Home</Link>
                    </li>
                    {isLoggedIn && (
                        <>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleFleetSelection('Gulfstream')}>
                                    Fleet Overview: Gulfstream
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleFleetSelection('Bombardier')}>
                                    Fleet Overview: Bombardier
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleFleetSelection('Airbus')}>
                                    Fleet Overview: Airbus
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleFleetSelection('Boeing')}>
                                    Fleet Overview: Boeing
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleMembershipSelection('Platinum')}>
                                    Platinum Membership
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleMembershipSelection('Gold')}>
                                    Gold Membership
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <button className="sidebar-links" onClick={() => handleMembershipSelection('Silver')}>
                                    Silver Membership
                                </button>
                            </li>
                            <li className="sidebar-item">
                                <Link to="/inflight" className="sidebar-links">Inflight Experience</Link>
                                <ul className="inflight-submenu">
                                    <li className="inflight-item">
                                        <button className="inflight-links" onClick={handleInflightEntertainment}>
                                            Inflight Entertainment
                                        </button>
                                    </li>
                                    <li className="inflight-item">
                                        <button className="inflight-links" onClick={handleMealSelection}>
                                            Meal Selection
                                        </button>
                                    </li>
                                    <li className="inflight-item">
                                        <button className="inflight-links" onClick={handleSeatAdjustment}>
                                            Seat Adjustment
                                        </button>
                                    </li>
                                </ul>
                            </li>
                            <li className="sidebar-item">
                                <Link to="/dashboard" className="sidebar-links">Dashboard</Link>
                            </li>
                            <li className="sidebar-item">
                                <Link to="/account-settings" className="sidebar-links">Account Settings</Link>
                            </li>
                            <li className="sidebar-item">
                                <Link to="/logout" className="sidebar-links">Logout</Link>
                            </li>
                        </>
                    )}
                    <li className="sidebar-item">
                        <Link to="/contact" className="sidebar-links">Contact Us</Link>
                    </li>
                </ul>
                <div className="sidebar-extras">
                    <div className="recent-activity">
                        <h3>Recent Activity</h3>
                        <ul>
                            {recentActivity.map((activity, index) => (
                                <li key={index}>{activity}</li>
                            ))}
                        </ul>
                    </div>
                    <div className="language-selector">
                        <label htmlFor="language-select">Language:</label>
                        <select id="language-select" value={language} onChange={handleLanguageChange}>
                            <option value="en">English</option>
                            <option value="fr">French</option>
                            <option value="es">Spanish</option>
                        </select>
                    </div>
                    <div className="theme-switcher">
                        <label htmlFor="theme-toggle">Theme:</label>
                        <button id="theme-toggle" onClick={toggleTheme}>
                            {theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
                        </button>
                    </div>
                    <div className="ai-assistant">
                        <button className="ai-button" onClick={handleAIInteraction}>
                            {aiAssistantActive ? 'Deactivate AI Assistant' : 'Activate AI Assistant'}
                        </button>
                        {aiAssistantActive && (
                            <div className="ai-assistant-interface">
                                <p>How can I assist you today?</p>
                            </div>
                        )}
                    </div>
                    <div className="notifications">
                        <button className="notifications-button" onClick={handleNotifications}>
                            Notifications {notifications.length > 0 ? `(${notifications.length})` : ''}
                        </button>
                        {notifications.length > 0 && (
                            <div className="notifications-dropdown">
                                {notifications.map((notification, index) => (
                                    <div key={index} className="notification-item">
                                        {notification}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    <div className="voice-controls">
                        <button className="voice-button" onClick={handleVoiceControl}>
                            Voice Control
                        </button>
                    </div>
                </div>
                <div className="sidebar-socials">
                    {/* Add social media icons here with hover effects */}
                </div>
            </div>
        </>
    );
};

export default Sidebar;
