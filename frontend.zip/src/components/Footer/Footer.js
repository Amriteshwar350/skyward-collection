import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer-container">
            <div className="footer-content">
                <div className="footer-branding">
                    <img src="/assets/images/logo.png" alt="Skyward Collection Logo" className="footer-logo" />
                    <p className="footer-tagline">Elevating Your Travel Experience</p>
                </div>
                <div className="footer-links">
                    <a href="/">Home</a>
                    <a href="/about">About Us</a>
                    <a href="/services">Services</a>
                    <a href="/contact">Contact</a>
                </div>
                <div className="footer-social">
                    <a href="#" className="social-icon"><i className="fab fa-facebook-f"></i></a>
                    <a href="#" className="social-icon"><i className="fab fa-twitter"></i></a>
                    <a href="#" className="social-icon"><i className="fab fa-instagram"></i></a>
                    <a href="#" className="social-icon"><i className="fab fa-linkedin-in"></i></a>
                </div>
                <div className="footer-contact">
                    <p>Contact Us: +123 456 7890</p>
                    <p>Email: contact@skywardcollection.com</p>
                </div>
            </div>
            <div className="footer-bottom">
                <p>© 2024 Skyward Collection. All rights reserved.</p>
            </div>
        </footer>
    );
}

export default Footer;
