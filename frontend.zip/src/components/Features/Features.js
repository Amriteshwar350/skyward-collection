import React from 'react';
import './Features.css';

const Features = () => {
    return (
        <section className="features-container">
            <div className="feature">
                <div className="feature-card">
                    <div className="feature-front">
                        <img src="/assets/images/bespoke-travel.jpg" alt="Bespoke Travel" />
                        <h3>Bespoke Travel</h3>
                    </div>
                    <div className="feature-back">
                        <h3>Bespoke Travel</h3>
                        <p>Experience tailored luxury with our bespoke travel options, crafted to your every need. From the moment you book to the end of your journey, everything is designed with perfection.</p>
                    </div>
                </div>
            </div>
            <div className="feature">
                <div className="feature-card">
                    <div className="feature-front">
                        <img src="/assets/images/global-reach.jpg" alt="Global Reach" />
                        <h3>Global Reach</h3>
                    </div>
                    <div className="feature-back">
                        <h3>Global Reach</h3>
                        <p>Connect with the world effortlessly. Our global reach ensures you can travel to any destination in the utmost luxury and comfort, with seamless service across continents.</p>
                    </div>
                </div>
            </div>
            <div className="feature">
                <div className="feature-card">
                    <div className="feature-front">
                        <img src="/assets/images/unmatched-comfort.jpg" alt="Unmatched Comfort" />
                        <h3>Unmatched Comfort</h3>
                    </div>
                    <div className="feature-back">
                        <h3>Unmatched Comfort</h3>
                        <p>Relax and unwind in the pinnacle of comfort aboard our state-of-the-art fleet. Every detail has been considered to provide an unrivaled travel experience.</p>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Features;
