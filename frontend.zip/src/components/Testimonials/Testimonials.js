import React, { useState } from 'react';
import './Testimonials.css';

const Testimonials = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const sections = [
        {
            title: "A Vision of Luxury",
            content: "At Skyward Collection, luxury isn't just a service; it's our ethos. Our founder's vision was to transcend the ordinary, crafting an unparalleled experience where every detail is a testament to exclusivity and sophistication.",
            image: "/assets/images/vision-of-luxury.jpg"
        },
        {
            title: "Expectations",
            content: "Skyward Collection redefines the art of travel. In one extraordinary journey, we facilitated a seamless 72-hour trip spanning three continents. With precision and care, we ensured our client arrived refreshed and ready, demonstrating that luxury knows no bounds.",
            image: "/assets/images/expectations.jpg"
        },
        {
            title: "The Pinnacle of Luxury Travel",
            content: "Experience a world where luxury isn't an option but a standard. Our fleet, our services, and our commitment to excellence are all designed with one purpose: to elevate your journey to the pinnacle of opulence.",
            image: "/assets/images/pinnacle-of-luxury.jpg"
        },
        {
            title: "A Journey Like No Other",
            content: "Your journey with Skyward Collection is more than just travel; it's a carefully curated experience. From booking to arrival, every moment is tailored to your desires, ensuring that your journey is as luxurious as your destination.",
            image: "/assets/images/journey-like-no-other.jpg"
        }
    ];

    const handleCircleClick = (index) => {
        setCurrentIndex(index);
    };

    return (
        <section className="testimonials-container">
            <h2 className="section-title">Redefining Luxury</h2>
            <div className="testimonials-carousel">
                {sections.map((section, index) => (
                    <div 
                        key={index} 
                        className={`testimonial-item ${currentIndex === index ? 'active' : ''}`}
                        style={{ display: currentIndex === index ? 'flex' : 'none' }}
                    >
                        <div className="testimonial-text">
                            <h3 className="testimonial-title">{section.title}</h3>
                            <p className="testimonial-quote">{section.content}</p>
                        </div>
                        <img src={section.image} alt={section.title} className="testimonial-image" />
                    </div>
                ))}
            </div>
            <div className="testimonials-navigation">
                {sections.map((_, index) => (
                    <span 
                        key={index} 
                        className={`nav-circle ${currentIndex === index ? 'active' : ''}`} 
                        onClick={() => handleCircleClick(index)}
                    ></span>
                ))}
            </div>
            <div className="testimonial-guidance">
                <p className="navigation-title">Explore Our Luxury Journeys</p>
            </div>
        </section>
    );
}

export default Testimonials;
