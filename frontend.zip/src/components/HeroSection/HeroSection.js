import React from 'react';
import './HeroSection.css';

const HeroSection = () => {
    const scrollToSection = () => {
        const section = document.getElementById('features-section');
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    };

    return (
        <div className="hero-container">
            <h1 className="hero-heading">Ascend to Unrivaled Luxury</h1>
            <p className="hero-subheading">
            Beyond Luxury – Where Every Flight is a Masterpiece
            </p>
            <button className="cta-button" onClick={scrollToSection}>Discover More</button>
        </div>
    );
}

export default HeroSection;
