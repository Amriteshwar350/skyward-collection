import React, { useState } from 'react';
import axios from 'axios';
import styles from './BookFlight.module.css';

const aircraftOptions = {
    Gulfstream: ['G700', 'G800', 'G650'],
    Bombardier: ['Global 7500', 'Challenger 650', 'Learjet 75'],
    Airbus: ['A350', 'A320'],
    Boeing: ['737', '757'],
    Helicopter: ['Bell 429', 'Airbus H160'],
};

const BookMyFlight = () => {
    const [departure, setDeparture] = useState('');
    const [destination, setDestination] = useState('');
    const [date, setDate] = useState('');
    const [returnDate, setReturnDate] = useState('');
    const [passengers, setPassengers] = useState('');
    const [manufacturer, setManufacturer] = useState('');
    const [aircraft, setAircraft] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token'); // Ensure the user is logged in

        if (!token) {
            setError('You must be logged in to book a flight');
            return;
        }

        try {
            const response = await axios.post(
                'http://localhost:5000/api/flights/book',
                {
                    departure,
                    destination,
                    departureDate: date,
                    arrivalDate: returnDate,
                    passengers,
                    carrier: `${manufacturer} - ${aircraft}`,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`, // Include JWT token
                    },
                }
            );

            setMessage('Flight booked successfully!');
            setError('');
            // Optionally reset the form after a successful booking
            setDeparture('');
            setDestination('');
            setDate('');
            setReturnDate('');
            setPassengers('');
            setManufacturer('');
            setAircraft('');
        } catch (err) {
            setError(err.response?.data?.message || 'Error booking the flight');
            setMessage('');
        }
    };

    const handleManufacturerChange = (e) => {
        const selectedManufacturer = e.target.value;
        setManufacturer(selectedManufacturer);
        setAircraft(''); // Reset aircraft selection if manufacturer changes
    };

    return (
        <div id="book-my-flight" className={styles['book-flight-container']}>
            <h2 className={styles['luxury-tagline']}>Embark on a Journey Like No Other</h2>
            <p className={styles['tagline-subtext']}>Tailored luxury flights crafted for your unique needs</p>
            <form onSubmit={handleSubmit} className={styles['book-flight-form']}>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>✈️</span>
                    <input
                        type="text"
                        placeholder="Departure"
                        value={departure}
                        onChange={(e) => setDeparture(e.target.value)}
                        className={styles['book-flight-input']}
                        required
                    />
                </div>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>📍</span>
                    <input
                        type="text"
                        placeholder="Destination"
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        className={styles['book-flight-input']}
                        required
                    />
                </div>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>📅</span>
                    <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className={styles['book-flight-input']}
                        required
                    />
                </div>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>↩️</span>
                    <input
                        type="date"
                        value={returnDate}
                        onChange={(e) => setReturnDate(e.target.value)}
                        className={styles['book-flight-input']}
                        placeholder="Return Date"
                    />
                </div>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>👥</span>
                    <input
                        type="number"
                        placeholder="Number of Passengers"
                        value={passengers}
                        onChange={(e) => setPassengers(e.target.value)}
                        className={styles['book-flight-input']}
                        min="1"
                        required
                    />
                </div>
                <div className={styles['book-flight-input-group']}>
                    <span className={styles['book-flight-input-icon']}>🏭</span>
                    <select
                        value={manufacturer}
                        onChange={handleManufacturerChange}
                        className={`${styles['book-flight-input']} ${styles['aircraft-select']}`}
                        required
                    >
                        <option value="">Select Your Aircraft Partner</option>
                        {Object.keys(aircraftOptions).map((manu) => (
                            <option key={manu} value={manu}>{`Luxurious ${manu} Collection`}</option>
                        ))}
                    </select>
                </div>
                {manufacturer && manufacturer !== '' && (
                    <div className={styles['book-flight-input-group']}>
                        <span className={styles['book-flight-input-icon']}>✈️</span>
                        <select
                            value={aircraft}
                            onChange={(e) => setAircraft(e.target.value)}
                            className={`${styles['book-flight-input']} ${styles['aircraft-select']}`}
                            required
                        >
                            <option value="">Select Your {manufacturer} Aircraft</option>
                            {aircraftOptions[manufacturer]?.map((air) => (
                                <option key={air} value={air}>{air}</option>
                            ))}
                        </select>
                    </div>
                )}
                <button type="submit" className={styles['book-flight-btn']}>Book Now</button>
            </form>
            {message && <p className={styles['success-message']}>{message}</p>}
            {error && <p className={styles['error-message']}>{error}</p>}
        </div>
    );
};

export default BookMyFlight;
